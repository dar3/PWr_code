package Program_Glowny;

import Biblioteka.Biblioteka;

public class Main {

    public static void main(String[] args) {

        System.out.println(Biblioteka.sinus(3.0,322));
        System.out.println(Math.sin(3.0));
        System.out.println(Biblioteka.cosinus(2.0, 7));
        System.out.println(Math.cos(2.0));
        System.out.println(Biblioteka.expon(2.0, 300));
        System.out.println(Math.exp(2.0));


    }
        }
