package Osoba;

import Konto.Konto;

public class Osoba {

    public static void aktywujKonto(Konto konto){

        konto.aktywuj();
    }


    public static void dezaktywujKonto(Konto konto){

        konto.dezaktywuj();
    }

}
